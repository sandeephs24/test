# CPData_Ingestion
Repository for Ingestion ADF of CP Data Project
